modus = function(x) {
  dens = density(x)
  dens$x[which.max(dens$y)]
}
